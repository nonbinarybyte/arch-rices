# KDE Translator Widget

## Features:

- Local LLM translation
- OpenAI translation (using API Key)
- Google Translate (using google API)
- Local Software Translation (TODO)

![Screenshot_20250209_233222](https://github.com/user-attachments/assets/b5b3bd15-882f-4cc0-91cc-7d81c452b1cf)
